# Ekwensi Digital Library

Starter website using Next.js, TypeScript and Supabase. Includes a responsive homepage, public library/search, signup/login, reader dashboard data model, book reader, and a protected admin route. This is a starter codebase and must be configured and tested before production. The admin route currently lists books; the full upload/edit/publish interface is a next development step.

## Setup on a phone-friendly workflow
1. Create a GitHub repository named `ekwensi-digital-library`.
2. Upload the contents of this folder to the repository (not only the ZIP file).
3. Create a Supabase project.
4. In Supabase SQL Editor, run `supabase/schema.sql` once.
5. Deploy the GitHub repository on Vercel and add environment variables from `.env.example` under Project Settings → Environment Variables.
6. Create an account using `/signup`, confirm email if requested, then copy the account UUID from Supabase → Authentication → Users.
7. Run this SQL with that UUID to grant admin access:

```sql
insert into public.user_roles(user_id,role)
values ('REPLACE-WITH-USER-UUID','admin')
on conflict(user_id) do update set role='admin';
```

Repeat for the owner's account and your developer account, using different emails and unique passwords. Do not use the shared password `2468` for production; it is too easy to guess. Never put Supabase service-role keys in frontend code or GitHub.

## Environment variables
`NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY`. The anon/publishable key is intended for browser use with Row Level Security; never expose the service-role key.

## Notes before launch
- The admin book upload/edit/publish interface, working favourite/bookmark actions, exact reader-position tracking, password reset, and full production QA remain to be completed.
- Only upload and publish books or excerpts you have the legal right to distribute. A website featuring an author's work does not automatically have permission to publish all of their books.
- Free hosting tiers and limits can change; verify current Vercel and Supabase terms.
