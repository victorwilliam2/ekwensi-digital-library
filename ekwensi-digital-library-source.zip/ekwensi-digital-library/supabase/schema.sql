-- Run once in the Supabase SQL Editor.
create extension if not exists pgcrypto;
create table if not exists public.user_roles(user_id uuid primary key references auth.users(id) on delete cascade,role text not null check(role in('admin','reader')) default 'reader',created_at timestamptz not null default now());
create table if not exists public.books(id uuid primary key default gen_random_uuid(),title text not null,author text not null default 'Cyprian Ekwensi',description text,cover_url text,format text not null check(format in('text','pdf')),content text,pdf_path text,publication_year integer,language text default 'English',is_published boolean not null default false,rights_confirmed boolean not null default false,created_by uuid references auth.users(id) on delete set null,created_at timestamptz not null default now(),updated_at timestamptz not null default now(),check((format='text' and content is not null) or (format='pdf' and pdf_path is not null)));
create table if not exists public.favourites(id uuid primary key default gen_random_uuid(),user_id uuid not null references auth.users(id) on delete cascade,book_id uuid not null references public.books(id) on delete cascade,created_at timestamptz not null default now(),unique(user_id,book_id));
create table if not exists public.bookmarks(id uuid primary key default gen_random_uuid(),user_id uuid not null references auth.users(id) on delete cascade,book_id uuid not null references public.books(id) on delete cascade,position integer not null default 0 check(position>=0),note text,created_at timestamptz not null default now(),unique(user_id,book_id,position));
create table if not exists public.reading_progress(id uuid primary key default gen_random_uuid(),user_id uuid not null references auth.users(id) on delete cascade,book_id uuid not null references public.books(id) on delete cascade,position integer not null default 0 check(position>=0),progress_percent integer not null default 0 check(progress_percent between 0 and 100),updated_at timestamptz not null default now(),unique(user_id,book_id));
create or replace function public.is_admin() returns boolean language sql stable security definer set search_path=public as $$ select exists(select 1 from public.user_roles where user_id=auth.uid() and role='admin'); $$;
revoke all on function public.is_admin() from public;grant execute on function public.is_admin() to authenticated;
alter table public.user_roles enable row level security;alter table public.books enable row level security;alter table public.favourites enable row level security;alter table public.bookmarks enable row level security;alter table public.reading_progress enable row level security;
create policy "Read own role" on public.user_roles for select to authenticated using(user_id=auth.uid() or public.is_admin());
create policy "Read published books or admin" on public.books for select using(is_published=true or public.is_admin());
create policy "Admin insert books" on public.books for insert to authenticated with check(public.is_admin() and created_by=auth.uid());
create policy "Admin update books" on public.books for update to authenticated using(public.is_admin()) with check(public.is_admin());
create policy "Admin delete books" on public.books for delete to authenticated using(public.is_admin());
create policy "Users manage own favourites" on public.favourites for all to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid());
create policy "Users manage own bookmarks" on public.bookmarks for all to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid());
create policy "Users manage own progress" on public.reading_progress for all to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid());
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types) values('book-covers','book-covers',true,5242880,array['image/png','image/jpeg','image/webp']) on conflict(id) do nothing;
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types) values('book-files','book-files',false,26214400,array['application/pdf']) on conflict(id) do nothing;
create policy "Public view covers" on storage.objects for select using(bucket_id='book-covers');
create policy "Admin upload covers" on storage.objects for insert to authenticated with check(bucket_id='book-covers' and public.is_admin() and (storage.foldername(name))[1]=auth.uid()::text);
create policy "Admin upload PDFs" on storage.objects for insert to authenticated with check(bucket_id='book-files' and public.is_admin() and (storage.foldername(name))[1]=auth.uid()::text);
create policy "Admin read PDFs" on storage.objects for select to authenticated using(bucket_id='book-files' and (public.is_admin() or exists(select 1 from public.books b where b.pdf_path=name and b.is_published=true)));
-- Never create a public policy that allows visitors to grant themselves an admin role.
