import {NextResponse} from 'next/server';import {createClient} from '@/lib/supabase/server';
export async function POST(request:Request){const sb=await createClient();await sb.auth.signOut();return NextResponse.redirect(new URL('/',request.url));}
