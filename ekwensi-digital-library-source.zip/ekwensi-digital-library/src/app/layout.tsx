import type { Metadata } from 'next';
import './globals.css';
import Header from '@/components/Header';
export const metadata:Metadata={title:'Ekwensi Digital Library',description:'Discover literary works by Cyprian Ekwensi.'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body><Header/>{children}<footer className="footer"><div className="container footer-inner"><span>EKWENSI DIGITAL LIBRARY</span><span>A home for literary discovery.</span></div></footer></body></html>}
