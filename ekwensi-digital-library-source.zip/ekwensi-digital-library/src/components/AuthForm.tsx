'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { createClient } from '@/lib/supabase/client';
export default function AuthForm({ mode }: {mode:'login'|'signup'}) {
 const [email,setEmail]=useState(''); const [password,setPassword]=useState(''); const [name,setName]=useState(''); const [message,setMessage]=useState(''); const [busy,setBusy]=useState(false); const router=useRouter();
 async function submit(e:React.FormEvent){e.preventDefault();setBusy(true);setMessage('');try{const sb=createClient();if(mode==='signup'){const {error}=await sb.auth.signUp({email,password,options:{data:{display_name:name}}});if(error)throw error;setMessage('Account created. Check your email if confirmation is enabled, then sign in.');}else{const {error}=await sb.auth.signInWithPassword({email,password});if(error)throw error;router.push('/dashboard');router.refresh();}}catch(e:any){setMessage(e.message||'Something went wrong.');}finally{setBusy(false)}}
 return <form className="form" onSubmit={submit}>{mode==='signup'&&<label>Display name<input required value={name} onChange={e=>setName(e.target.value)}/></label>}<label>Email<input type="email" autoComplete="email" required value={email} onChange={e=>setEmail(e.target.value)}/></label><label>Password<input type="password" minLength={8} required autoComplete={mode==='login'?'current-password':'new-password'} value={password} onChange={e=>setPassword(e.target.value)}/></label>{message&&<p className="notice">{message}</p>}<button className="btn primary" disabled={busy}>{busy?'Please wait…':mode==='login'?'Sign in':'Create account'}</button><p className="small center">{mode==='login'?'New reader?':'Already registered?'} <Link href={mode==='login'?'/signup':'/login'}>{mode==='login'?'Create an account':'Sign in'}</Link></p></form>
}
