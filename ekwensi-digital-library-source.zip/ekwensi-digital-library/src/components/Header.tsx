import Link from 'next/link';
import { BookOpen } from 'lucide-react';
import { createClient } from '@/lib/supabase/server';
export default async function Header() {
  let signedIn = false;
  try { const sb = await createClient(); const { data } = await sb.auth.getUser(); signedIn = !!data.user; } catch {}
  return <header className="header"><div className="container nav"><Link href="/" className="brand"><span className="brand-icon"><BookOpen size={22}/></span><span><b>EKWENSI</b><small>DIGITAL LIBRARY</small></span></Link><nav><Link href="/library">Library</Link>{signedIn && <Link href="/dashboard">My Reading</Link>}{signedIn && <Link href="/admin">Admin</Link>}{!signedIn && <Link href="/login">Sign in</Link>}</nav></div></header>;
}
